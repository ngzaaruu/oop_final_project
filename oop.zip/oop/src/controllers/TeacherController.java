package controllers;

import Model.academic.Course;
import Model.service.TeacherService;
import Model.users.Manager;
import Model.users.Student;
import Model.users.Teacher;
import Model.users.User;
import views.TeacherView;

import java.util.ArrayList;
import java.util.List;

public class TeacherController {

    private final TeacherService service;
    private final TeacherView view;

    public TeacherController(TeacherService service, TeacherView view) {
        this.service = service;
        this.view = view;
    }

    public void openMenu(Teacher teacher) {
        boolean running = true;
        while (running) {
            try {
                switch (view.showMenu()) {
                    case 1 -> view.showCourses(service.getAllCourses());
                    case 2 -> teachCourse(teacher);
                    case 3 -> view.showCourses(service.getTeacherCourses(teacher));
                    case 4 -> updateCourse(teacher);
                    case 5 -> updateCourseTarget(teacher);
                    case 6 -> viewStudents(teacher);
                    case 7 -> putMark(teacher);
                    case 8 -> sendComplaint(teacher);
                    case 9 -> sendMessage(teacher);
                    case 10 -> sendSupportRequest(teacher);
                    case 11 -> running = false;
                    default -> view.showError("Unknown option");
                }
            } catch (IllegalArgumentException | IllegalStateException e) {
                view.showError(e.getMessage());
            }
        }
    }

    private void teachCourse(Teacher teacher) {
        List<Course> courses = service.getAllCourses();
        view.showCourses(courses);
        service.teachCourse(teacher, selectCourse(courses), view.readLessonType());
        view.showSuccess("Course assigned to you.");
    }

    private void updateCourse(Teacher teacher) {
        Course course = selectTeacherCourse(teacher);
        service.updateCourse(teacher, course, view.readName(), view.readCredits());
        view.showSuccess("Course updated.");
    }

    private void updateCourseTarget(Teacher teacher) {
        Course course = selectTeacherCourse(teacher);
        service.updateCourseTarget(teacher, course, view.readMajorTarget(), view.readYearOfStudy());
        view.showSuccess("Course target updated.");
    }

    private void viewStudents(Teacher teacher) {
        Course course = selectTeacherCourse(teacher);
        view.showStudents(service.viewStudents(teacher, course));
    }

    private void putMark(Teacher teacher) {
        Course course = selectTeacherCourse(teacher);
        List<Student> students = service.viewStudents(teacher, course);
        view.showStudents(students);
        Student student = selectStudent(students);
        service.putMark(
                teacher,
                student,
                course,
                view.readScore("Attestation 1 (0-30): "),
                view.readScore("Attestation 2 (0-30): "),
                view.readScore("Final exam (0-40): ")
        );
        view.showSuccess("Mark saved.");
    }

    private void sendComplaint(Teacher teacher) {
        List<Manager> managers = getManagers();
        view.showManagers(managers);
        int managerIndex = view.readIndex("Manager number: ");
        if (managerIndex < 0 || managerIndex >= managers.size()) {
            throw new IllegalArgumentException("Manager not found");
        }

        Course course = selectTeacherCourse(teacher);
        List<Student> students = service.viewStudents(teacher, course);
        view.showStudents(students);
        service.sendComplaint(
                teacher,
                managers.get(managerIndex),
                selectStudent(students),
                view.readComplaintUrgency(),
                view.readComplaintDetails()
        );
        view.showSuccess("Complaint sent.");
    }

    private void sendMessage(Teacher teacher) {
        List<User> users = service.getMessageReceivers(teacher);
        view.showUsers(users);
        int index = view.readIndex("Receiver number: ");
        if (index < 0 || index >= users.size()) {
            throw new IllegalArgumentException("Receiver not found");
        }
        service.sendMessage(teacher, users.get(index), view.readMessageText());
        view.showSuccess("Message sent.");
    }

    private void sendSupportRequest(Teacher teacher) {
        service.sendSupportRequest(teacher, view.readRequestDescription());
        view.showSuccess("Support request sent.");
    }

    private Course selectTeacherCourse(Teacher teacher) {
        List<Course> courses = service.getTeacherCourses(teacher);
        view.showCourses(courses);
        return selectCourse(courses);
    }

    private Course selectCourse(List<Course> courses) {
        int index = view.readIndex("Course number: ");
        if (index < 0 || index >= courses.size()) {
            throw new IllegalArgumentException("Course not found");
        }
        return courses.get(index);
    }

    private Student selectStudent(List<Student> students) {
        int index = view.readIndex("Student number: ");
        if (index < 0 || index >= students.size()) {
            throw new IllegalArgumentException("Student not found");
        }
        return students.get(index);
    }

    private List<Manager> getManagers() {
        List<Manager> managers = new ArrayList<>();
        for (User user : Model.service.DataStorage.getInstance().getUsers()) {
            if (user instanceof Manager manager) {
                managers.add(manager);
            }
        }
        return managers;
    }
}
