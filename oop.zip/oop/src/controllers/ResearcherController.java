package controllers;

import Model.communication.Journal;
import Model.enums.CitationFormat;
import Model.research.ResearchPaper;
import Model.research.ResearchProject;
import Model.research.Researcher;
import Model.service.ResearchService;
import Model.service.UniversityService;
import Model.users.GraduateStudent;
import Model.users.User;
import views.ResearcherView;

import java.util.Comparator;
import java.util.List;

public class ResearcherController {

    private final ResearchService service;
    private final UniversityService universityService;
    private final ResearcherView view;

    public ResearcherController(ResearchService service, ResearcherView view) {
        this.service = service;
        this.universityService = new UniversityService();
        this.view = view;
    }

    public void openMenu(User user) {
        if (!(user instanceof Researcher)) {
            view.showError("Not a researcher!");
            return;
        }

        Researcher researcher = (Researcher) user;
        boolean running = true;

        while (running) {
            try {
                switch (view.showMenu()) {
                    case 1 -> view.showPapers(researcher.getResearchPapers());
                    case 2 -> addPaper(researcher);
                    case 3 -> view.showInfo("h-index", String.valueOf(service.calculateHIndex(researcher)));
                    case 4 -> printSortedPapers(researcher);
                    case 5 -> printCitation(researcher);
                    case 6 -> view.showProjects(researcher.getResearchProjects());
                    case 7 -> joinProject(researcher);
                    case 8 -> subscribeToJournal(user);
                    case 9 -> printAllResearchPapers();
                    case 10 -> printTopCitedResearcher();
                    case 11 -> printTopCitedResearcherBySchool();
                    case 12 -> printTopCitedResearcherByYear();
                    case 13 -> publishPaperToJournal(researcher);
                    case 14 -> viewDiplomaPapers(user);
                    case 15 -> addDiplomaPaper(user);
                    case 16 -> running = false;
                    default -> view.showError("Unknown option");
                }
            } catch (IllegalArgumentException | IllegalStateException e) {
                view.showError(e.getMessage());
            }
        }
    }

    private void addPaper(Researcher researcher) {
        ResearchPaper paper = view.readPaper();
        universityService.publishResearchPaper(researcher, paper);
        view.showSuccess("Paper added and research news published!");
    }

    private void printSortedPapers(Researcher researcher) {
        int choice = view.readSortOption();
        Comparator<ResearchPaper> comparator = switch (choice) {
            case 1 -> Comparator.naturalOrder();
            case 2 -> ResearchPaper::compareByCitations;
            case 3 -> ResearchPaper::compareByPages;
            case 4 -> null;
            default -> throw new IllegalArgumentException("Unknown sorting option");
        };

        if (comparator != null) {
            service.printPapers(researcher, comparator);
        }
    }

    private void printCitation(Researcher researcher) {
        List<ResearchPaper> papers = researcher.getResearchPapers();
        view.showPapers(papers);
        int index = view.readPaperIndex();

        if (index < 0 || index >= papers.size()) {
            throw new IllegalArgumentException("Paper not found");
        }

        CitationFormat format = view.readCitationFormat();
        view.showInfo("Citation", service.getCitation(papers.get(index), format));
    }

    private void joinProject(Researcher researcher) {
        List<ResearchProject> projects = service.getAllProjects();
        view.showProjects(projects);

        int index = view.readProjectIndex();
        if (index < 0 || index >= projects.size()) {
            throw new IllegalArgumentException("Project not found");
        }

        researcher.joinProject(projects.get(index));
        view.showSuccess("Joined project successfully!");
    }

    private void subscribeToJournal(User user) {
        Journal journal = view.chooseJournal(service.getJournals());
        service.subscribeToJournal(user, journal);
        view.showSuccess("Subscribed to journal: " + journal.getName());
    }

    private void printAllResearchPapers() {
        int choice = view.readSortOption();
        Comparator<ResearchPaper> comparator = switch (choice) {
            case 1 -> Comparator.naturalOrder();
            case 2 -> ResearchPaper::compareByCitations;
            case 3 -> ResearchPaper::compareByPages;
            case 4 -> null;
            default -> throw new IllegalArgumentException("Unknown sorting option");
        };

        if (comparator != null) {
            view.showPapers(service.getAllResearchPapers(comparator));
        }
    }

    private void printTopCitedResearcher() {
        Researcher top = service.getTopCitedResearcher();
        if (top == null) {
            view.showInfo("Top researcher", "No researchers found");
            return;
        }
        view.showInfo("Top researcher", top + " | citations: " + service.getTotalCitations(top));
    }

    private void printTopCitedResearcherBySchool() {
        String school = view.readSchool();
        Researcher top = service.getTopCitedResearcherBySchool(school);
        if (top == null) {
            view.showInfo("Top researcher", "No researchers found for " + school);
            return;
        }
        view.showInfo("Top researcher", top + " | citations: " + service.getTotalCitations(top));
    }

    private void printTopCitedResearcherByYear() {
        int year = view.readYear();
        Researcher top = service.getTopCitedResearcherByYear(year);
        if (top == null) {
            view.showInfo("Top researcher", "No researchers found for " + year);
            return;
        }
        view.showInfo("Top researcher", top + " | citations in " + year + ": " + service.getTotalCitationsByYear(top, year));
    }

    private void publishPaperToJournal(Researcher researcher) {
        List<ResearchPaper> papers = researcher.getResearchPapers();
        view.showPapers(papers);
        int paperIndex = view.readPaperIndex();
        if (paperIndex < 0 || paperIndex >= papers.size()) {
            throw new IllegalArgumentException("Paper not found");
        }

        Journal journal = view.chooseJournal(service.getJournals());
        service.publishPaperToJournal(journal, papers.get(paperIndex));
        view.showSuccess("Paper published to journal and subscribers notified.");
    }

    private void viewDiplomaPapers(User user) {
        if (!(user instanceof GraduateStudent graduateStudent)) {
            throw new IllegalArgumentException("Only graduate students have diploma papers");
        }
        view.showPapers(graduateStudent.getPublishedDiplomaPapers());
    }

    private void addDiplomaPaper(User user) {
        if (!(user instanceof GraduateStudent graduateStudent)) {
            throw new IllegalArgumentException("Only graduate students can add diploma papers");
        }

        List<ResearchPaper> papers = graduateStudent.getResearchPapers();
        view.showPapers(papers);
        int paperIndex = view.readPaperIndex();
        if (paperIndex < 0 || paperIndex >= papers.size()) {
            throw new IllegalArgumentException("Paper not found");
        }

        graduateStudent.addDiplomaPaper(papers.get(paperIndex));
        view.showSuccess("Diploma paper added.");
    }
}

