package controllers;

import Model.academic.Course;
import Model.communication.News;
import Model.communication.Request;
import Model.exceptions.DuplicateRegistrationException;
import Model.exceptions.LowHIndexException;
import Model.exceptions.MaxCreditsExceededException;
import Model.exceptions.TooManyFailsException;
import Model.research.Researcher;
import Model.service.ManagerService;
import Model.users.GraduateStudent;
import Model.users.Manager;
import Model.users.Student;
import Model.users.Teacher;
import Model.users.User;
import views.ManagerView;

import java.util.List;

public class ManagerController {

    private final ManagerService service;
    private final ManagerView view;

    public ManagerController(ManagerService service, ManagerView view) {
        this.service = service;
        this.view = view;
    }

    public void openMenu(Manager manager) {
        boolean running = true;
        while (running) {
            try {
                switch (view.showMenu()) {
                    case 1 -> createCourse(manager);
                    case 2 -> assignCourse(manager);
                    case 3 -> approveRegistration(manager);
                    case 4 -> view.showStudents(service.getStudentsSortedByName());
                    case 5 -> view.showTeachers(service.getTeachers());
                    case 6 -> view.showCourses(service.getCourses());
                    case 7 -> publishNews(manager);
                    case 8 -> view.showNews(service.getNews());
                    case 9 -> createAcademicReport(manager);
                    case 10 -> view.showRequests(service.getRequests(manager));
                    case 11 -> signRequest(manager);
                    case 12 -> createOfficialMessage(manager);
                    case 13 -> view.showOfficialMessages(service.getOfficialMessages());
                    case 14 -> commentNews(manager);
                    case 15 -> viewNewsComments();
                    case 16 -> assignSupervisor(manager);
                    case 17 -> running = false;
                    default -> view.showError("Unknown option");
                }
            } catch (IllegalArgumentException | IllegalStateException |
                     MaxCreditsExceededException | TooManyFailsException |
                     DuplicateRegistrationException | LowHIndexException e) {
                view.showError(e.getMessage());
            }
        }
    }

    private void createCourse(Manager manager) {
        service.createCourse(
                manager,
                view.readCourseId(),
                view.readCourseName(),
                view.readCourseType(),
                view.readCredits(),
                view.readMajorTarget(),
                view.readYearOfStudy()
        );
        view.showSuccess("Course created.");
    }

    private void assignCourse(Manager manager) {
        List<Course> courses = service.getCourses();
        List<Teacher> teachers = service.getTeachers();
        view.showCourses(courses);
        Course course = selectCourse(courses);
        view.showTeachers(teachers);
        Teacher teacher = selectTeacher(teachers);
        service.assignCourseToTeacher(manager, course, teacher, view.readLessonType());
        view.showSuccess("Course assigned.");
    }

    private void approveRegistration(Manager manager)
            throws MaxCreditsExceededException, TooManyFailsException, DuplicateRegistrationException {
        List<Student> students = service.getStudents();
        List<Course> courses = service.getCourses();
        view.showStudents(students);
        Student student = selectStudent(students);
        view.showCourses(courses);
        Course course = selectCourse(courses);
        service.approveRegistration(manager, student, course);
        view.showSuccess("Registration approved.");
    }

    private void publishNews(Manager manager) {
        List<User> users = service.getUsers();
        view.showUsers(users);
        int index = view.readIndex("Author number: ");
        if (index < 0 || index >= users.size()) {
            throw new IllegalArgumentException("Author not found");
        }
        service.publishNews(manager, users.get(index), view.readNewsTitle(), view.readNewsContent(), view.readNewsType());
        view.showSuccess("News published.");
    }

    private void createAcademicReport(Manager manager) {
        int type = view.readReportType();
        if (type == 1) {
            List<Student> students = service.getStudents();
            view.showStudents(students);
            view.showText(service.createStudentReport(manager, selectStudent(students)).toString());
            return;
        }
        if (type == 2) {
            view.showText(service.createAcademicPerformanceReport(manager).toString());
            return;
        }
        throw new IllegalArgumentException("Unknown report type");
    }

    private void signRequest(Manager manager) {
        List<Request> requests = service.getRequests(manager);
        view.showRequests(requests);
        int index = view.readIndex("Request number: ");
        if (index < 0 || index >= requests.size()) {
            throw new IllegalArgumentException("Request not found");
        }
        service.signRequest(manager, requests.get(index));
        view.showSuccess("Request signed.");
    }

    private void createOfficialMessage(Manager manager) {
        service.createOfficialMessage(
                manager,
                view.readOfficialMessageTitle(),
                view.readOfficialMessageDetails()
        );
        view.showSuccess("Official message created.");
    }

    private void commentNews(Manager manager) {
        List<News> news = service.getNews();
        view.showNews(news);
        service.addCommentToNews(manager, selectNews(news), view.readCommentText());
        view.showSuccess("Comment added.");
    }

    private void viewNewsComments() {
        List<News> news = service.getNews();
        view.showNews(news);
        view.showComments(selectNews(news).getComments());
    }

    private void assignSupervisor(Manager manager) throws LowHIndexException {
        List<GraduateStudent> graduateStudents = service.getGraduateStudents();
        view.showGraduateStudents(graduateStudents);
        GraduateStudent graduateStudent = selectGraduateStudent(graduateStudents);

        List<Researcher> researchers = service.getResearchers();
        view.showResearchers(researchers);
        Researcher supervisor = selectResearcher(researchers);

        service.assignSupervisor(manager, graduateStudent, supervisor);
        view.showSuccess("Supervisor assigned.");
    }

    private Course selectCourse(List<Course> courses) {
        int index = view.readIndex("Course number: ");
        if (index < 0 || index >= courses.size()) {
            throw new IllegalArgumentException("Course not found");
        }
        return courses.get(index);
    }

    private Teacher selectTeacher(List<Teacher> teachers) {
        int index = view.readIndex("Teacher number: ");
        if (index < 0 || index >= teachers.size()) {
            throw new IllegalArgumentException("Teacher not found");
        }
        return teachers.get(index);
    }

    private Student selectStudent(List<Student> students) {
        int index = view.readIndex("Student number: ");
        if (index < 0 || index >= students.size()) {
            throw new IllegalArgumentException("Student not found");
        }
        return students.get(index);
    }

    private News selectNews(List<News> news) {
        int index = view.readIndex("News number: ");
        if (index < 0 || index >= news.size()) {
            throw new IllegalArgumentException("News not found");
        }
        return news.get(index);
    }

    private GraduateStudent selectGraduateStudent(List<GraduateStudent> students) {
        int index = view.readIndex("Graduate student number: ");
        if (index < 0 || index >= students.size()) {
            throw new IllegalArgumentException("Graduate student not found");
        }
        return students.get(index);
    }

    private Researcher selectResearcher(List<Researcher> researchers) {
        int index = view.readIndex("Researcher number: ");
        if (index < 0 || index >= researchers.size()) {
            throw new IllegalArgumentException("Researcher not found");
        }
        return researchers.get(index);
    }
}
