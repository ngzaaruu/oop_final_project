package controllers;

import Model.academic.Course;
import Model.academic.StudentOrganization;
import Model.exceptions.DuplicateRegistrationException;
import Model.exceptions.MaxCreditsExceededException;
import Model.exceptions.TooManyFailsException;
import Model.service.StudentService;
import Model.users.Student;
import Model.users.Teacher;
import views.StudentView;

import java.util.List;

public class StudentController {

    private final StudentService service;
    private final StudentView view;

    public StudentController(StudentService service, StudentView view) {
        this.service = service;
        this.view = view;
    }

    public void openMenu(Student student) {
        boolean running = true;
        while (running) {
            try {
                switch (view.showMenu()) {
                    case 1 -> view.showCourses(service.getAvailableCourses());
                    case 2 -> registerCourse(student);
                    case 3 -> dropCourse(student);
                    case 4 -> view.showCourses(service.getCourses(student));
                    case 5 -> view.showMarks(service.getMarks(student));
                    case 6 -> view.showText(service.getTranscript(student));
                    case 7 -> showTeacherInfo(student);
                    case 8 -> rateTeacher(student);
                    case 9 -> openOrganizationMenu(student);
                    case 10 -> sendSupportRequest(student);
                    case 11 -> running = false;
                    default -> view.showError("Unknown option");
                }
            } catch (IllegalArgumentException | IllegalStateException |
                     MaxCreditsExceededException | TooManyFailsException |
                     DuplicateRegistrationException e) {
                view.showError(e.getMessage());
            }
        }
    }

    private void registerCourse(Student student)
            throws MaxCreditsExceededException, TooManyFailsException, DuplicateRegistrationException {
        List<Course> courses = service.getAvailableCourses();
        view.showCourses(courses);
        service.registerCourse(student, selectCourse(courses));
        view.showSuccess("Registered for course.");
    }

    private void dropCourse(Student student) {
        List<Course> courses = service.getCourses(student);
        view.showCourses(courses);
        service.dropCourse(student, selectCourse(courses));
        view.showSuccess("Course dropped.");
    }

    private void showTeacherInfo(Student student) {
        List<Course> courses = service.getCourses(student);
        view.showCourses(courses);
        view.showText(service.getTeacherInfo(student, selectCourse(courses)));
    }

    private void rateTeacher(Student student) {
        List<Course> courses = service.getCourses(student);
        view.showCourses(courses);
        Course course = selectCourse(courses);
        List<Teacher> teachers = course.getInstructors();
        view.showTeachers(teachers);
        int index = view.readIndex("Teacher number: ");
        if (index < 0 || index >= teachers.size()) {
            throw new IllegalArgumentException("Teacher not found");
        }
        service.rateTeacher(student, teachers.get(index), view.readRating());
        view.showSuccess("Teacher rated.");
    }

    private void openOrganizationMenu(Student student) {
        boolean running = true;
        while (running) {
            view.showText("[1] View organizations\n[2] Create organization\n[3] Join organization\n[4] Back");
            switch (view.readIndex("Choose: ") + 1) {
                case 1 -> view.showOrganizations(service.getAllOrganizations());
                case 2 -> {
                    service.createOrganization(student, view.readOrganizationName());
                    view.showSuccess("Organization created.");
                }
                case 3 -> joinOrganization(student);
                case 4 -> running = false;
                default -> view.showError("Unknown option");
            }
        }
    }

    private void joinOrganization(Student student) {
        List<StudentOrganization> organizations = service.getAllOrganizations();
        view.showOrganizations(organizations);
        int index = view.readIndex("Organization number: ");
        if (index < 0 || index >= organizations.size()) {
            throw new IllegalArgumentException("Organization not found");
        }
        service.joinOrganization(student, organizations.get(index));
        view.showSuccess("Organization joined.");
    }

    private void sendSupportRequest(Student student) {
        service.sendSupportRequest(student, view.readRequestDescription());
        view.showSuccess("Support request sent.");
    }

    private Course selectCourse(List<Course> courses) {
        int index = view.readIndex("Course number: ");
        if (index < 0 || index >= courses.size()) {
            throw new IllegalArgumentException("Course not found");
        }
        return courses.get(index);
    }
}
