package controllers;

import Model.communication.Journal;
import Model.service.UserPortalService;
import Model.users.User;
import views.UserPortalView;

import java.util.List;

public class UserPortalController {

    private final UserPortalService service;
    private final UserPortalView view;

    public UserPortalController(UserPortalService service, UserPortalView view) {
        this.service = service;
        this.view = view;
    }

    public void openMenu(User user) {
        boolean running = true;
        while (running) {
            try {
                switch (view.showMenu()) {
                    case 1 -> view.showNews(service.getNews());
                    case 2 -> view.showJournals(service.getJournals());
                    case 3 -> subscribeToJournal(user);
                    case 4 -> view.showMessages(service.getInbox(user));
                    case 5 -> view.showMessages(service.getSentMessages(user));
                    case 6 -> sendMessage(user);
                    case 7 -> running = false;
                    default -> view.showError("Unknown option");
                }
            } catch (IllegalArgumentException | IllegalStateException e) {
                view.showError(e.getMessage());
            }
        }
    }

    private void subscribeToJournal(User user) {
        Journal journal = view.chooseJournal(service.getJournals());
        service.subscribeToJournal(user, journal);
        view.showSuccess("Subscribed to journal.");
    }

    private void sendMessage(User sender) {
        List<User> users = service.getMessageReceivers(sender);
        view.showUsers(users);
        int index = view.readIndex("Receiver number: ");
        if (index < 0 || index >= users.size()) {
            throw new IllegalArgumentException("Receiver not found");
        }
        service.sendMessage(sender, users.get(index), view.readMessageText());
        view.showSuccess("Message sent.");
    }
}
