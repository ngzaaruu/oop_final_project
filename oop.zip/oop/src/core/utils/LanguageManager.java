package core.utils;

import Model.enums.Language;

public final class LanguageManager {

    private static Language currentLanguage = Language.EN;

    private LanguageManager() {
    }

    public static Language getCurrentLanguage() {
        return currentLanguage;
    }

    public static void setCurrentLanguage(Language language) {
        if (language != null) {
            currentLanguage = language;
        }
    }

    public static String text(String en, String kz, String ru) {
        return switch (currentLanguage) {
            case KZ -> kz;
            case RU -> ru;
            default -> en;
        };
    }
}
