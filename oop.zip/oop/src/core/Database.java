package core;

import Model.service.DataStorage;

public final class Database {

    public static final String DEFAULT_FILE = DataStorage.DEFAULT_FILE;

    private Database() {
    }

    public static DataStorage getInstance() {
        return DataStorage.getInstance();
    }

    public static boolean loadDefault() {
        if (!DataStorage.fileExists(DEFAULT_FILE)) {
            return false;
        }

        DataStorage.load(DEFAULT_FILE);
        return true;
    }

    public static void saveDefault() {
        DataStorage.getInstance().saveDefault();
    }
}
