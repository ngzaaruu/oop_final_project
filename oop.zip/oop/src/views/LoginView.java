package views;

import core.utils.ConsolePrinter;
import core.utils.LanguageManager;

import java.util.Scanner;

public class LoginView {

    private final Scanner scanner;

    public LoginView(Scanner scanner) {
        this.scanner = scanner;
    }

    public String readEmail() {
        System.out.print("Email: ");
        return scanner.nextLine().trim();
    }

    public String readPassword() {
        System.out.print(LanguageManager.text("Password: ", "Qupiya soz: ", "Пароль: "));
        return scanner.nextLine().trim();
    }

    public void showLoginSuccess(String role) {
        ConsolePrinter.printSuccess(LanguageManager.text("Logged in as ", "Kirgen rol: ", "Вход как ") + role);
    }

    public void showError(String message) {
        ConsolePrinter.printError(message);
    }
}
