package views;

import Model.academic.Course;
import Model.communication.Comment;
import Model.communication.News;
import Model.communication.OfficialMessage;
import Model.communication.Request;
import Model.enums.CourseType;
import Model.enums.LessonType;
import Model.enums.NewsType;
import Model.research.Researcher;
import Model.users.GraduateStudent;
import Model.users.Student;
import Model.users.Teacher;
import Model.users.User;
import core.utils.ConsolePrinter;
import core.utils.LanguageManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ManagerView {

    private final Scanner scanner;

    public ManagerView(Scanner scanner) {
        this.scanner = scanner;
    }

    public int showMenu() {
        ConsolePrinter.printMenu(LanguageManager.text("MANAGER MENU", "MANAGER MENU", "МЕНЮ МЕНЕДЖЕРА"), new String[]{
                LanguageManager.text("Create course", "Kurs quru", "Создать курс"),
                LanguageManager.text("Assign course to teacher", "Kursty mugalimge beru", "Назначить курс преподавателю"),
                LanguageManager.text("Approve registration", "Registraciyany rastau", "Одобрить регистрацию"),
                LanguageManager.text("View students", "Studentter", "Студенты"),
                LanguageManager.text("View teachers", "Mugalimder", "Преподаватели"),
                LanguageManager.text("View courses", "Kurstar", "Курсы"),
                LanguageManager.text("Publish news", "Janalıq shygaru", "Опубликовать новость"),
                LanguageManager.text("View news", "Janalıqtardy koru", "Посмотреть новости"),
                LanguageManager.text("Create academic report", "Academic report quru", "Создать отчет"),
                LanguageManager.text("View requests", "Suranystardy koru", "Посмотреть запросы"),
                LanguageManager.text("Sign request", "Suranysty qol qoyu", "Подписать запрос"),
                LanguageManager.text("Create official message", "Official habar quru", "Создать официальное сообщение"),
                LanguageManager.text("View official messages", "Official habarlardy koru", "Посмотреть официальные сообщения"),
                LanguageManager.text("Comment news", "News comment qosu", "Комментировать новость"),
                LanguageManager.text("View news comments", "News commentterin koru", "Посмотреть комментарии"),
                LanguageManager.text("Assign graduate supervisor", "Supervisor tagaiyndau", "Назначить научного руководителя"),
                LanguageManager.text("Back", "Artqa", "Назад")
        });
        return readInt(promptChoose());
    }

    public int readCourseId() { return readInt("Course id: "); }
    public String readCourseName() { return readRequired("Course name: "); }
    public int readCredits() { return readInt("Credits: "); }
    public String readMajorTarget() { return readRequired("Major target: "); }
    public int readYearOfStudy() { return readInt("Year of study: "); }
    public String readNewsTitle() { return readRequired("News title: "); }
    public String readNewsContent() { return readRequired("News content: "); }
    public int readReportType() {
        ConsolePrinter.printMenu("REPORT TYPE", new String[]{"One student", "All students"});
        return readInt(promptChoose());
    }
    public String readCommentText() { return readRequired("Comment: "); }
    public String readOfficialMessageTitle() { return readRequired("Official message title: "); }
    public String readOfficialMessageDetails() { return readRequired("Official message details: "); }
    public int readIndex(String prompt) { return readInt(prompt) - 1; }

    public CourseType readCourseType() {
        ConsolePrinter.printMenu("COURSE TYPE", new String[]{"Major", "Minor", "Free elective"});
        return switch (readInt(promptChoose())) {
            case 1 -> CourseType.MAJOR;
            case 2 -> CourseType.MINOR;
            case 3 -> CourseType.FREE_ELECTIVE;
            default -> throw new IllegalArgumentException("Unknown course type");
        };
    }

    public LessonType readLessonType() {
        ConsolePrinter.printMenu("LESSON TYPE", new String[]{"Lecture", "Practice"});
        return switch (readInt(promptChoose())) {
            case 1 -> LessonType.LECTURE;
            case 2 -> LessonType.PRACTICE;
            default -> throw new IllegalArgumentException("Unknown lesson type");
        };
    }

    public NewsType readNewsType() {
        ConsolePrinter.printMenu("NEWS TYPE", new String[]{"General", "Research", "Announcement"});
        return switch (readInt(promptChoose())) {
            case 1 -> NewsType.GENERAL;
            case 2 -> NewsType.RESEARCH;
            case 3 -> NewsType.ANNOUNCEMENT;
            default -> throw new IllegalArgumentException("Unknown news type");
        };
    }

    public void showCourses(List<Course> courses) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < courses.size(); i++) {
            Course course = courses.get(i);
            rows.add(Arrays.asList(
                    String.valueOf(i + 1),
                    course.getName(),
                    String.valueOf(course.getCredits()),
                    course.getType().name(),
                    formatInstructors(course),
                    formatLessons(course)
            ));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Course", "Credits", "Type", "Instructors", "Lessons"), rows);
    }

    public void showStudents(List<Student> students) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < students.size(); i++) {
            Student student = students.get(i);
            rows.add(Arrays.asList(String.valueOf(i + 1), student.getFullName(), student.getMajor(), String.valueOf(student.getYearOfStudy())));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Student", "Major", "Year"), rows);
    }

    public void showGraduateStudents(List<GraduateStudent> students) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < students.size(); i++) {
            GraduateStudent student = students.get(i);
            rows.add(Arrays.asList(String.valueOf(i + 1), student.getFullName(), student.getMajor()));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Graduate student", "Major"), rows);
    }

    public void showTeachers(List<Teacher> teachers) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < teachers.size(); i++) {
            Teacher teacher = teachers.get(i);
            rows.add(Arrays.asList(String.valueOf(i + 1), teacher.getFullName(), teacher.getPosition().name()));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Teacher", "Position"), rows);
    }

    public void showUsers(List<User> users) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < users.size(); i++) {
            User user = users.get(i);
            rows.add(Arrays.asList(String.valueOf(i + 1), user.getFullName(), user.getEmail(), user.getClass().getSimpleName()));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Name", "Email", "Role"), rows);
    }

    public void showResearchers(List<Researcher> researchers) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < researchers.size(); i++) {
            Researcher researcher = researchers.get(i);
            rows.add(Arrays.asList(String.valueOf(i + 1), String.valueOf(researcher), String.valueOf(researcher.calculateHIndex())));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Researcher", "h-index"), rows);
    }

    public void showNews(List<News> news) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < news.size(); i++) {
            News item = news.get(i);
            rows.add(Arrays.asList(String.valueOf(i + 1), item.getTitle(), item.getTopic().name(), item.getAuthor().getFullName()));
        }
        rows.clear();
        for (int i = 0; i < news.size(); i++) {
            News item = news.get(i);
            rows.add(Arrays.asList(
                    String.valueOf(i + 1),
                    item.isPinned() ? "YES" : "NO",
                    item.getTitle(),
                    item.getTopic().name(),
                    item.getAuthor().getFullName()
            ));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Pinned", "Title", "Topic", "Author"), rows);
    }

    public void showComments(List<Comment> comments) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < comments.size(); i++) {
            Comment comment = comments.get(i);
            rows.add(Arrays.asList(String.valueOf(i + 1), comment.getAuthor().getFullName(), comment.getText()));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Author", "Comment"), rows);
    }

    public void showRequests(List<Request> requests) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < requests.size(); i++) {
            Request request = requests.get(i);
            rows.add(Arrays.asList(String.valueOf(i + 1), request.getSender().getFullName(), request.getDescription(), request.getStatus().name(), request.isSigned() ? "yes" : "no"));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Sender", "Description", "Status", "Signed"), rows);
    }

    public void showOfficialMessages(List<OfficialMessage> messages) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < messages.size(); i++) {
            OfficialMessage message = messages.get(i);
            rows.add(Arrays.asList(String.valueOf(i + 1), message.getTitle(), message.getDetails(), message.getCreatedBy().getFullName()));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Title", "Details", "Created by"), rows);
    }

    public void showText(String text) { System.out.println(text); }
    public void showSuccess(String message) { ConsolePrinter.printSuccess(message); }
    public void showError(String message) { ConsolePrinter.printError(message); }

    private String formatInstructors(Course course) {
        List<String> names = new ArrayList<>();
        for (Teacher teacher : course.getInstructors()) {
            names.add(teacher.getFullName());
        }
        return String.join(", ", names);
    }

    private String formatLessons(Course course) {
        List<String> lessons = new ArrayList<>();
        for (Model.academic.Lesson lesson : course.getLessons()) {
            lessons.add(lesson.getType() + ": " + lesson.getInstructor().getFullName());
        }
        return String.join("; ", lessons);
    }

    private String readRequired(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine().trim();
            if (!value.isEmpty()) {
                return value;
            }
            ConsolePrinter.printError("Value cannot be empty");
        }
    }

    private int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                ConsolePrinter.printError("Enter a valid number");
            }
        }
    }

    private String promptChoose() {
        return LanguageManager.text("Choose: ", "Tandau: ", "Выберите: ");
    }
}
