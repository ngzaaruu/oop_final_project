package views;

import Model.communication.Journal;
import Model.enums.CitationFormat;
import Model.research.ResearchPaper;
import Model.research.ResearchProject;
import core.utils.ConsolePrinter;
import core.utils.LanguageManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class ResearcherView {

    private final Scanner scanner;

    public ResearcherView(Scanner scanner) {
        this.scanner = scanner;
    }

    public int showMenu() {
        ConsolePrinter.printMenu(LanguageManager.text("RESEARCHER MENU", "ZERTTEUSHI MENU", "МЕНЮ ИССЛЕДОВАТЕЛЯ"), new String[]{
                LanguageManager.text("View my papers", "Maqalalarym", "Мои статьи"),
                LanguageManager.text("Add paper", "Maqala qosu", "Добавить статью"),
                LanguageManager.text("View h-index", "h-index koru", "Посмотреть h-index"),
                LanguageManager.text("Print papers sorted by date / citations / pages", "Maqalalardy sorttau", "Сортировать статьи"),
                LanguageManager.text("Get citation (Plain Text / BibTeX)", "Citation alu", "Получить цитирование"),
                LanguageManager.text("View research projects", "Research projectter", "Исследовательские проекты"),
                LanguageManager.text("Join research project", "Projectke kiru", "Присоединиться к проекту"),
                LanguageManager.text("Subscribe to journal", "Journalga jazylu", "Подписаться на журнал"),
                LanguageManager.text("View all research papers", "Barlyq research maqalalar", "Все исследовательские статьи"),
                LanguageManager.text("View top cited researcher", "Top cited researcher", "Самый цитируемый исследователь"),
                LanguageManager.text("View top cited researcher by school", "School boiynsha top researcher", "Самый цитируемый по школе"),
                LanguageManager.text("View top cited researcher by year", "Jyl boiynsha top researcher", "Самый цитируемый по году"),
                LanguageManager.text("Publish paper to journal", "Maqalany jurnalga jariyalau", "Опубликовать статью в журнале"),
                LanguageManager.text("View diploma papers", "Diplom maqalalary", "Посмотреть дипломные статьи"),
                LanguageManager.text("Add diploma paper", "Diplom maqalasyn qosu", "Добавить дипломную статью"),
                LanguageManager.text("Back", "Artqa", "Назад")
        });
        return readInt(promptChoose());
    }

    public void showPapers(List<ResearchPaper> papers) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < papers.size(); i++) {
            ResearchPaper paper = papers.get(i);
            rows.add(Arrays.asList(
                    String.valueOf(i + 1),
                    paper.getTitle(),
                    paper.getJournal(),
                    String.valueOf(paper.getCitations()),
                    String.valueOf(paper.getPages())
            ));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Title", "Journal", "Citations", "Pages"), rows);
    }

    public ResearchPaper readPaper() {
        String title = readLine("Title: ");
        String authorsText = readLine("Authors (comma separated): ");
        String journal = readLine("Journal: ");
        int pages = readInt("Pages: ");
        int citations = readInt("Citations: ");
        String doi = readLine("DOI: ");

        List<String> authors = new ArrayList<>();
        for (String author : authorsText.split(",")) {
            if (!author.trim().isEmpty()) {
                authors.add(author.trim());
            }
        }

        return new ResearchPaper(title, authors, journal, pages, citations, new Date(), doi);
    }

    public int readSortOption() {
        ConsolePrinter.printMenu("SORT PAPERS", new String[]{"Date", "Citations", "Pages", "Back"});
        return readInt(promptChoose());
    }

    public CitationFormat readCitationFormat() {
        ConsolePrinter.printMenu("CITATION FORMAT", new String[]{"Plain Text", "BibTeX"});
        int choice = readInt(promptChoose());
        return choice == 2 ? CitationFormat.BIBTEX : CitationFormat.PLAIN_TEXT;
    }

    public int readPaperIndex() {
        return readInt("Paper number: ") - 1;
    }

    public void showProjects(List<ResearchProject> projects) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < projects.size(); i++) {
            ResearchProject project = projects.get(i);
            rows.add(Arrays.asList(
                    String.valueOf(i + 1),
                    project.getProjectId(),
                    project.getTopic(),
                    String.valueOf(project.getParticipants().size())
            ));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "ID", "Topic", "Participants"), rows);
    }

    public int readProjectIndex() {
        return readInt("Project number: ") - 1;
    }

    public String readSchool() {
        return readLine("School/major/department: ");
    }

    public int readYear() {
        return readInt("Year: ");
    }

    public Journal chooseJournal(List<Journal> journals) {
        if (!journals.isEmpty()) {
            List<List<String>> rows = new ArrayList<>();
            for (int i = 0; i < journals.size(); i++) {
                rows.add(Arrays.asList(String.valueOf(i + 1), journals.get(i).getName()));
            }
            ConsolePrinter.printTable(Arrays.asList("#", "Journal"), rows);
        }

        String value = readLine("Journal number or new journal name: ");
        try {
            int index = Integer.parseInt(value) - 1;
            if (index >= 0 && index < journals.size()) {
                return journals.get(index);
            }
        } catch (NumberFormatException ignored) {
        }

        return new Journal(value);
    }

    public void showSuccess(String message) {
        ConsolePrinter.printSuccess(message);
    }

    public void showError(String message) {
        ConsolePrinter.printError(message);
    }

    public void showInfo(String label, String value) {
        ConsolePrinter.printInfo(label, value);
    }

    private String readLine(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    private int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                ConsolePrinter.printError(LanguageManager.text("Enter a valid number", "Durys san engiziniz", "Введите корректное число"));
            }
        }
    }

    private String promptChoose() {
        return LanguageManager.text("Choose: ", "Tandau: ", "Выберите: ");
    }
}
