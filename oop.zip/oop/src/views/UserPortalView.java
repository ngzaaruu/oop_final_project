package views;

import Model.communication.Journal;
import Model.communication.Message;
import Model.communication.News;
import Model.users.User;
import core.utils.ConsolePrinter;
import core.utils.LanguageManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class UserPortalView {

    private final Scanner scanner;

    public UserPortalView(Scanner scanner) {
        this.scanner = scanner;
    }

    public int showMenu() {
        ConsolePrinter.printMenu(LanguageManager.text("USER PORTAL", "PAIDALANUSHY PORTALY", "ПОРТАЛ ПОЛЬЗОВАТЕЛЯ"), new String[]{
                LanguageManager.text("View news", "Janalıqtardy koru", "Посмотреть новости"),
                LanguageManager.text("View journals", "Jurnaldardy koru", "Посмотреть журналы"),
                LanguageManager.text("Subscribe to journal", "Jurnalga jazylu", "Подписаться на журнал"),
                LanguageManager.text("View inbox", "Kirgen habarlar", "Входящие сообщения"),
                LanguageManager.text("View sent messages", "Jiberilgen habarlar", "Отправленные сообщения"),
                LanguageManager.text("Send message", "Habar jiberu", "Отправить сообщение"),
                LanguageManager.text("Back", "Artqa", "Назад")
        });
        return readInt(promptChoose());
    }

    public void showNews(List<News> news) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < news.size(); i++) {
            News item = news.get(i);
            rows.add(Arrays.asList(
                    String.valueOf(i + 1),
                    item.isPinned() ? "YES" : "NO",
                    item.getTitle(),
                    item.getTopic().name(),
                    item.getAuthor().getFullName()
            ));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Pinned", "Title", "Topic", "Author"), rows);
    }

    public void showJournals(List<Journal> journals) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < journals.size(); i++) {
            Journal journal = journals.get(i);
            rows.add(Arrays.asList(String.valueOf(i + 1), journal.getName(), String.valueOf(journal.getPapers().size())));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Journal", "Papers"), rows);
    }

    public void showUsers(List<User> users) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < users.size(); i++) {
            User user = users.get(i);
            rows.add(Arrays.asList(String.valueOf(i + 1), user.getFullName(), user.getEmail(), user.getClass().getSimpleName()));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Name", "Email", "Role"), rows);
    }

    public void showMessages(List<Message> messages) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < messages.size(); i++) {
            Message message = messages.get(i);
            rows.add(Arrays.asList(String.valueOf(i + 1), message.getSender().getFullName(), message.getReceiver().getFullName(), message.getText()));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "From", "To", "Text"), rows);
    }

    public Journal chooseJournal(List<Journal> journals) {
        showJournals(journals);
        String value = readRequired(LanguageManager.text("Journal number or new journal name: ", "Jurnal nomeri nemese jana aty: ", "Номер журнала или новое название: "));
        try {
            int index = Integer.parseInt(value) - 1;
            if (index >= 0 && index < journals.size()) {
                return journals.get(index);
            }
        } catch (NumberFormatException ignored) {
        }
        return new Journal(value);
    }

    public int readIndex(String prompt) {
        return readInt(prompt) - 1;
    }

    public String readMessageText() {
        return readRequired(LanguageManager.text("Message: ", "Habar: ", "Сообщение: "));
    }

    public void showSuccess(String message) {
        ConsolePrinter.printSuccess(message);
    }

    public void showError(String message) {
        ConsolePrinter.printError(message);
    }

    private String readRequired(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine().trim();
            if (!value.isEmpty()) {
                return value;
            }
            ConsolePrinter.printError(LanguageManager.text("Value cannot be empty", "Bos bolmauy kerek", "Значение не может быть пустым"));
        }
    }

    private int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                ConsolePrinter.printError(LanguageManager.text("Enter a valid number", "Durys san engiziniz", "Введите корректное число"));
            }
        }
    }

    private String promptChoose() {
        return LanguageManager.text("Choose: ", "Tandau: ", "Выберите: ");
    }
}
