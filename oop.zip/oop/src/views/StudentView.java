package views;

import Model.academic.Course;
import Model.academic.Mark;
import Model.academic.StudentOrganization;
import Model.users.Teacher;
import core.utils.ConsolePrinter;
import core.utils.LanguageManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class StudentView {

    private final Scanner scanner;

    public StudentView(Scanner scanner) {
        this.scanner = scanner;
    }

    public int showMenu() {
        ConsolePrinter.printMenu(LanguageManager.text("STUDENT MENU", "STUDENT MENU", "МЕНЮ СТУДЕНТА"), new String[]{
                LanguageManager.text("View available courses", "Kurstar", "Посмотреть доступные курсы"),
                LanguageManager.text("Register course", "Kursqa tirkelu", "Зарегистрироваться на курс"),
                LanguageManager.text("Drop course", "Kurstan shygu", "Отменить курс"),
                LanguageManager.text("View my courses", "Menin kurstarym", "Мои курсы"),
                LanguageManager.text("View marks", "Bagalardy koru", "Посмотреть оценки"),
                LanguageManager.text("View transcript", "Transcript koru", "Посмотреть транскрипт"),
                LanguageManager.text("View teacher info", "Mugalim aqparaty", "Информация о преподавателе"),
                LanguageManager.text("Rate teacher", "Mugalimdi bagalau", "Оценить преподавателя"),
                LanguageManager.text("Student organizations", "Student uiymdary", "Студенческие организации"),
                LanguageManager.text("Send tech support request", "Tech supportqa suranys", "Отправить запрос в техподдержку"),
                LanguageManager.text("Back", "Artqa", "Назад")
        });
        return readInt(promptChoose());
    }

    public void showCourses(List<Course> courses) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < courses.size(); i++) {
            Course course = courses.get(i);
            rows.add(Arrays.asList(
                    String.valueOf(i + 1),
                    course.getName(),
                    String.valueOf(course.getCredits()),
                    course.getType().name(),
                    course.getMajorTarget(),
                    String.valueOf(course.getYearOfStudy()),
                    formatLessons(course)
            ));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Course", "Credits", "Type", "Major", "Year", "Lessons"), rows);
    }

    public void showMarks(Map<Course, Mark> marks) {
        List<List<String>> rows = new ArrayList<>();
        for (Map.Entry<Course, Mark> entry : marks.entrySet()) {
            rows.add(Arrays.asList(entry.getKey().getName(), String.valueOf(entry.getValue().getTotal()), entry.getValue().getLetterGrade()));
        }
        ConsolePrinter.printTable(Arrays.asList("Course", "Total", "Grade"), rows);
    }

    public void showTeachers(List<Teacher> teachers) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < teachers.size(); i++) {
            Teacher teacher = teachers.get(i);
            rows.add(Arrays.asList(String.valueOf(i + 1), teacher.getFullName(), teacher.getPosition().name()));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Teacher", "Position"), rows);
    }

    public void showOrganizations(List<StudentOrganization> organizations) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < organizations.size(); i++) {
            StudentOrganization organization = organizations.get(i);
            rows.add(Arrays.asList(
                    String.valueOf(i + 1),
                    organization.getName(),
                    organization.getHead() == null ? "" : organization.getHead().getFullName(),
                    String.valueOf(organization.getMembers().size())
            ));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Organization", "Head", "Members"), rows);
    }

    public int readIndex(String prompt) {
        return readInt(prompt) - 1;
    }

    public int readRating() {
        return readInt(LanguageManager.text("Rating (1-5): ", "Baga (1-5): ", "Оценка (1-5): "));
    }

    public String readOrganizationName() {
        return readRequired(LanguageManager.text("Organization name: ", "Uiym aty: ", "Название организации: "));
    }

    public String readRequestDescription() {
        return readRequired(LanguageManager.text("Request description: ", "Suranys sipattamasy: ", "Описание запроса: "));
    }

    public void showText(String text) {
        System.out.println(text);
    }

    public void showSuccess(String message) {
        ConsolePrinter.printSuccess(message);
    }

    public void showError(String message) {
        ConsolePrinter.printError(message);
    }

    private String readRequired(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine().trim();
            if (!value.isEmpty()) {
                return value;
            }
            ConsolePrinter.printError(LanguageManager.text("Value cannot be empty", "Bos bolmauy kerek", "Значение не может быть пустым"));
        }
    }

    private int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                ConsolePrinter.printError(LanguageManager.text("Enter a valid number", "Durys san engiziniz", "Введите корректное число"));
            }
        }
    }

    private String formatLessons(Course course) {
        List<String> lessons = new ArrayList<>();
        for (Model.academic.Lesson lesson : course.getLessons()) {
            lessons.add(lesson.getType() + ": " + lesson.getInstructor().getFullName());
        }
        return String.join("; ", lessons);
    }

    private String promptChoose() {
        return LanguageManager.text("Choose: ", "Tandau: ", "Выберите: ");
    }
}
