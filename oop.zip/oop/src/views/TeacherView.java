package views;

import Model.academic.Course;
import Model.enums.ComplaintUrgency;
import Model.enums.LessonType;
import Model.users.Manager;
import Model.users.Student;
import Model.users.User;
import core.utils.ConsolePrinter;
import core.utils.LanguageManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class TeacherView {

    private final Scanner scanner;

    public TeacherView(Scanner scanner) {
        this.scanner = scanner;
    }

    public int showMenu() {
        ConsolePrinter.printMenu(LanguageManager.text("TEACHER MENU", "MUGALIM MENU", "МЕНЮ ПРЕПОДАВАТЕЛЯ"), new String[]{
                LanguageManager.text("View all courses", "Barlyq kurstar", "Посмотреть все курсы"),
                LanguageManager.text("Start teaching course", "Kursty bastau", "Начать вести курс"),
                LanguageManager.text("View my courses", "Menin kurstarym", "Мои курсы"),
                LanguageManager.text("Update course", "Kursty ozgertu", "Изменить курс"),
                LanguageManager.text("Update course target", "Kurs bagytyn ozgertu", "Изменить цель курса"),
                LanguageManager.text("View students in course", "Kurstagy studentter", "Студенты курса"),
                LanguageManager.text("Put mark", "Baga qoyu", "Поставить оценку"),
                LanguageManager.text("Send complaint", "Shagym jiberu", "Отправить жалобу"),
                LanguageManager.text("Send message", "Habar jiberu", "Отправить сообщение"),
                LanguageManager.text("Send tech support request", "Tech supportqa suranys", "Запрос в техподдержку"),
                LanguageManager.text("Back", "Artqa", "Назад")
        });
        return readInt(promptChoose());
    }

    public void showCourses(List<Course> courses) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < courses.size(); i++) {
            Course course = courses.get(i);
            rows.add(Arrays.asList(
                    String.valueOf(i + 1),
                    course.getName(),
                    String.valueOf(course.getCredits()),
                    course.getType().name(),
                    formatLessons(course)
            ));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Course", "Credits", "Type", "Lessons"), rows);
    }

    public void showStudents(List<Student> students) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < students.size(); i++) {
            Student student = students.get(i);
            rows.add(Arrays.asList(String.valueOf(i + 1), student.getFullName(), student.getMajor()));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Student", "Major"), rows);
    }

    public void showManagers(List<Manager> managers) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < managers.size(); i++) {
            Manager manager = managers.get(i);
            rows.add(Arrays.asList(String.valueOf(i + 1), manager.getFullName(), manager.getManagerType().name()));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Manager", "Type"), rows);
    }

    public void showUsers(List<User> users) {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < users.size(); i++) {
            User user = users.get(i);
            rows.add(Arrays.asList(String.valueOf(i + 1), user.getFullName(), user.getEmail(), user.getClass().getSimpleName()));
        }
        ConsolePrinter.printTable(Arrays.asList("#", "Name", "Email", "Role"), rows);
    }

    public int readIndex(String prompt) { return readInt(prompt) - 1; }
    public String readName() { return readRequired(LanguageManager.text("New course name: ", "Jana kurs aty: ", "Новое название курса: ")); }
    public int readCredits() { return readInt(LanguageManager.text("Credits: ", "Kredit: ", "Кредиты: ")); }
    public String readMajorTarget() { return readRequired(LanguageManager.text("Major target: ", "Major: ", "Специальность: ")); }
    public int readYearOfStudy() { return readInt(LanguageManager.text("Year of study: ", "Oqu jyly: ", "Год обучения: ")); }
    public String readComplaintDetails() { return readRequired(LanguageManager.text("Complaint details: ", "Shagym matini: ", "Текст жалобы: ")); }
    public String readMessageText() { return readRequired(LanguageManager.text("Message: ", "Habar: ", "Сообщение: ")); }
    public String readRequestDescription() { return readRequired(LanguageManager.text("Request description: ", "Suranys sipattamasy: ", "Описание запроса: ")); }

    public LessonType readLessonType() {
        ConsolePrinter.printMenu(LanguageManager.text("LESSON TYPE", "SABAQ TURI", "ТИП ЗАНЯТИЯ"), new String[]{
                LanguageManager.text("Lecture", "Lekciya", "Лекция"),
                LanguageManager.text("Practice", "Praktika", "Практика")
        });
        return switch (readInt(promptChoose())) {
            case 1 -> LessonType.LECTURE;
            case 2 -> LessonType.PRACTICE;
            default -> throw new IllegalArgumentException("Unknown lesson type");
        };
    }

    public ComplaintUrgency readComplaintUrgency() {
        ConsolePrinter.printMenu(LanguageManager.text("COMPLAINT URGENCY", "SHAGYM MANZY", "СРОЧНОСТЬ ЖАЛОБЫ"), new String[]{
                LanguageManager.text("Low", "Tomen", "Низкая"),
                LanguageManager.text("Medium", "Ortasha", "Средняя"),
                LanguageManager.text("High", "Joqary", "Высокая")
        });
        return switch (readInt(promptChoose())) {
            case 1 -> ComplaintUrgency.LOW;
            case 2 -> ComplaintUrgency.MEDIUM;
            case 3 -> ComplaintUrgency.HIGH;
            default -> throw new IllegalArgumentException("Unknown urgency level");
        };
    }

    public double readScore(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Double.parseDouble(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                ConsolePrinter.printError(LanguageManager.text("Enter a valid number", "Durys san engiziniz", "Введите корректное число"));
            }
        }
    }

    public void showSuccess(String message) { ConsolePrinter.printSuccess(message); }
    public void showError(String message) { ConsolePrinter.printError(message); }

    private String readRequired(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine().trim();
            if (!value.isEmpty()) {
                return value;
            }
            ConsolePrinter.printError(LanguageManager.text("Value cannot be empty", "Bos bolmauy kerek", "Значение не может быть пустым"));
        }
    }

    private int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                ConsolePrinter.printError(LanguageManager.text("Enter a valid number", "Durys san engiziniz", "Введите корректное число"));
            }
        }
    }

    private String formatLessons(Course course) {
        List<String> lessons = new ArrayList<>();
        for (Model.academic.Lesson lesson : course.getLessons()) {
            lessons.add(lesson.getType() + ": " + lesson.getInstructor().getFullName());
        }
        return String.join("; ", lessons);
    }

    private String promptChoose() {
        return LanguageManager.text("Choose: ", "Tandau: ", "Выберите: ");
    }
}
