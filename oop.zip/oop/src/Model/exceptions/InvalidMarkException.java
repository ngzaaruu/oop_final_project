package Model.exceptions;

public class InvalidMarkException extends Exception {
    public InvalidMarkException(String message) {
        super(message);
    }
}
