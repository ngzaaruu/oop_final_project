package Model.service;

import Model.academic.Course;
import Model.academic.Mark;
import Model.academic.StudentOrganization;
import Model.communication.Request;
import Model.exceptions.DuplicateRegistrationException;
import Model.exceptions.MaxCreditsExceededException;
import Model.exceptions.TooManyFailsException;
import Model.users.Student;
import Model.users.Teacher;

import java.util.List;
import java.util.Map;

public class StudentService {

    private final DataStorage storage;
    private final Logger logger;

    public StudentService() {
        this(DataStorage.getInstance(), Logger.getInstance());
    }

    public StudentService(DataStorage storage, Logger logger) {
        this.storage = storage;
        this.logger = logger;
    }

    public List<Course> getAvailableCourses() {
        return storage.getCourses();
    }

    public void registerCourse(Student student, Course course)
            throws MaxCreditsExceededException, TooManyFailsException, DuplicateRegistrationException {
        requireStudent(student);
        if (course == null) {
            throw new IllegalArgumentException("Course cannot be null");
        }

        student.registerCourse(course);
        logger.log(student, "Registered for course: " + course.getName());
        persist();
    }

    public void dropCourse(Student student, Course course) {
        requireStudent(student);
        if (course == null) {
            throw new IllegalArgumentException("Course cannot be null");
        }

        student.dropCourse(course);
        logger.log(student, "Dropped course: " + course.getName());
        persist();
    }

    public List<Course> getCourses(Student student) {
        requireStudent(student);
        return student.getCourses();
    }

    public Map<Course, Mark> getMarks(Student student) {
        requireStudent(student);
        return student.viewMarks();
    }

    public String getTranscript(Student student) {
        requireStudent(student);
        return student.getTranscript();
    }

    public String getTeacherInfo(Student student, Course course) {
        requireStudent(student);
        return student.viewTeacherInfo(course);
    }

    public void rateTeacher(Student student, Teacher teacher, int rating) {
        requireStudent(student);
        if (teacher == null) {
            throw new IllegalArgumentException("Teacher cannot be null");
        }

        student.rateTeacher(teacher, rating);
        logger.log(student, "Rated teacher " + teacher.getFullName() + ": " + rating);
        persist();
    }

    public StudentOrganization createOrganization(Student student, String name) {
        requireStudent(student);
        StudentOrganization organization = new StudentOrganization(name);
        organization.setHead(student);
        student.joinOrganization(organization);
        storage.addStudentOrganization(organization);
        logger.log(student, "Created student organization: " + name);
        persist();
        return organization;
    }

    public void joinOrganization(Student student, StudentOrganization organization) {
        requireStudent(student);
        if (organization == null) {
            throw new IllegalArgumentException("Organization cannot be null");
        }
        student.joinOrganization(organization);
        logger.log(student, "Joined student organization: " + organization.getName());
        persist();
    }

    public List<StudentOrganization> getOrganizations(Student student) {
        requireStudent(student);
        return student.getOrganizations();
    }

    public List<StudentOrganization> getAllOrganizations() {
        return storage.getStudentOrganizations();
    }

    public Request sendSupportRequest(Student student, String description) {
        requireStudent(student);
        Request request = new Request(description, student);
        logger.log(student, "Sent support request: " + description);
        persist();
        return request;
    }

    private void requireStudent(Student student) {
        if (student == null) {
            throw new IllegalArgumentException("Student is required");
        }
    }

    private void persist() {
        storage.saveDefault();
    }
}
