package Model.service;

import Model.communication.Journal;
import Model.enums.CitationFormat;
import Model.research.ResearchPaper;
import Model.research.ResearchProject;
import Model.research.Researcher;
import Model.users.User;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ResearchService {

    private final DataStorage storage;

    public ResearchService() {
        this.storage = DataStorage.getInstance();
    }

    public void addPaper(Researcher researcher, ResearchPaper paper) {
        if (researcher == null || paper == null) {
            throw new IllegalArgumentException("Researcher and paper cannot be null");
        }

        researcher.addResearchPaper(paper);
        storage.addPaper(paper);
        persist();
    }

    public int calculateHIndex(Researcher researcher) {
        if (researcher == null) {
            throw new IllegalArgumentException("Researcher cannot be null");
        }
        return researcher.calculateHIndex();
    }

    public void printPapers(Researcher researcher, Comparator<ResearchPaper> comparator) {
        if (researcher == null || comparator == null) {
            throw new IllegalArgumentException("Researcher and comparator cannot be null");
        }
        researcher.printPapers(comparator);
    }

    public String getCitation(ResearchPaper paper, CitationFormat format) {
        if (paper == null) {
            throw new IllegalArgumentException("Paper cannot be null");
        }
        return paper.getCitation(format);
    }

    public List<ResearchProject> getAllProjects() {
        return storage.getResearchProjects();
    }

    public void addProject(ResearchProject project) {
        storage.addResearchProject(project);
        persist();
    }

    public List<Journal> getJournals() {
        return storage.getJournals();
    }

    public void subscribeToJournal(User user, Journal journal) {
        if (user == null || journal == null) {
            throw new IllegalArgumentException("User and journal cannot be null");
        }

        storage.addJournal(journal);
        journal.subscribe(user);
        persist();
    }

    public List<Researcher> getAllResearchers() {
        List<Researcher> researchers = new ArrayList<>();
        for (User user : storage.getUsers()) {
            if (user instanceof Researcher researcher) {
                researchers.add(researcher);
            }
        }
        return researchers;
    }

    public List<ResearchPaper> getAllResearchPapers(Comparator<ResearchPaper> comparator) {
        List<ResearchPaper> papers = new ArrayList<>();
        for (Researcher researcher : getAllResearchers()) {
            for (ResearchPaper paper : researcher.getResearchPapers()) {
                if (!papers.contains(paper)) {
                    papers.add(paper);
                }
            }
        }
        papers.sort(comparator);
        return papers;
    }

    public Researcher getTopCitedResearcher() {
        return new ReportService().findTopCitedResearcher(getAllResearchers());
    }

    public int getTotalCitations(Researcher researcher) {
        return new ReportService().getTotalCitations(researcher);
    }

    public Researcher getTopCitedResearcherBySchool(String school) {
        return new ReportService().findTopCitedResearcherBySchool(getAllResearchers(), school);
    }

    public Researcher getTopCitedResearcherByYear(int year) {
        return new ReportService().findTopCitedResearcherByYear(getAllResearchers(), year);
    }

    public int getTotalCitationsByYear(Researcher researcher, int year) {
        return new ReportService().getTotalCitationsByYear(researcher, year);
    }

    public void publishPaperToJournal(Journal journal, ResearchPaper paper) {
        if (journal == null || paper == null) {
            throw new IllegalArgumentException("Journal and paper cannot be null");
        }
        storage.addJournal(journal);
        journal.publishPaper(paper);
        persist();
    }

    private void persist() {
        storage.saveDefault();
    }
}

