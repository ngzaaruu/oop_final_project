package Model.service;

import Model.academic.Course;
import Model.academic.Lesson;
import Model.academic.Mark;
import Model.communication.Request;
import Model.enums.ComplaintUrgency;
import Model.enums.LessonType;
import Model.users.Manager;
import Model.users.Student;
import Model.users.Teacher;
import Model.users.User;

import java.util.List;
import java.util.Date;

public class TeacherService {

    private final DataStorage storage;
    private final Logger logger;

    public TeacherService() {
        this(DataStorage.getInstance(), Logger.getInstance());
    }

    public TeacherService(DataStorage storage, Logger logger) {
        this.storage = storage;
        this.logger = logger;
    }

    public List<Course> getAllCourses() {
        return storage.getCourses();
    }

    public List<Course> getTeacherCourses(Teacher teacher) {
        requireTeacher(teacher);
        List<Course> courses = new java.util.ArrayList<>();
        for (Course course : storage.getCourses()) {
            if (course.getInstructors().contains(teacher)) {
                courses.add(course);
            }
        }
        return courses;
    }

    public Lesson teachCourse(Teacher teacher, Course course, LessonType lessonType) {
        requireTeacher(teacher);
        if (course == null || lessonType == null) {
            throw new IllegalArgumentException("Course and lesson type cannot be null");
        }
        ensureLessonTypeAvailable(course, lessonType);

        teacher.teachCourse(course);
        Lesson lesson = new Lesson(generateLessonId(course, lessonType), lessonType, new Date(), teacher, course);
        logger.log(teacher, "Started teaching " + lessonType + " for course: " + course.getName());
        persist();
        return lesson;
    }

    public void updateCourse(Teacher teacher, Course course, String newName, int newCredits) {
        requireTeacher(teacher);
        teacher.manageCourse(course, newName, newCredits);
        logger.log(teacher, "Updated course: " + course.getName());
        persist();
    }

    public void updateCourseTarget(Teacher teacher, Course course, String majorTarget, int yearOfStudy) {
        requireTeacher(teacher);
        teacher.updateCourseTarget(course, majorTarget, yearOfStudy);
        logger.log(teacher, "Updated course target: " + course.getName());
        persist();
    }

    public List<Student> viewStudents(Teacher teacher, Course course) {
        requireTeacher(teacher);
        return teacher.viewStudents(course);
    }

    public Mark putMark(Teacher teacher, Student student, Course course,
                        double attestation1, double attestation2, double finalExam) {
        requireTeacher(teacher);
        if (student == null || course == null) {
            throw new IllegalArgumentException("Student and course cannot be null");
        }

        Mark mark = new Mark(attestation1, attestation2, finalExam, student, course);
        logger.log(teacher, "Put mark for " + student.getFullName() + " in " + course.getName());
        persist();
        return mark;
    }

    public Request sendComplaint(Teacher teacher, Manager dean, Student student,
                                 ComplaintUrgency urgency, String details) {
        requireTeacher(teacher);
        Request request = teacher.sendComplaint(dean, student, urgency, details);
        logger.log(teacher, "Sent complaint about " + student.getFullName());
        persist();
        return request;
    }

    public List<User> getMessageReceivers(Teacher teacher) {
        requireTeacher(teacher);
        List<User> users = new java.util.ArrayList<>();
        for (User user : storage.getUsers()) {
            if (!user.equals(teacher)) {
                users.add(user);
            }
        }
        return users;
    }

    public void sendMessage(Teacher teacher, User receiver, String text) {
        requireTeacher(teacher);
        if (receiver == null) {
            throw new IllegalArgumentException("Receiver cannot be null");
        }
        teacher.sendMessage(receiver, text);
        logger.log(teacher, "Sent message to " + receiver.getFullName());
        persist();
    }

    public Request sendSupportRequest(Teacher teacher, String description) {
        requireTeacher(teacher);
        Request request = new Request(description, teacher);
        logger.log(teacher, "Sent support request: " + description);
        persist();
        return request;
    }

    private void requireTeacher(Teacher teacher) {
        if (teacher == null) {
            throw new IllegalArgumentException("Teacher is required");
        }
    }

    private int generateLessonId(Course course, LessonType lessonType) {
        return Math.abs((course.hashCode() + lessonType.hashCode() + course.getLessons().size()) % 1_000_000);
    }

    private void ensureLessonTypeAvailable(Course course, LessonType lessonType) {
        for (Lesson lesson : course.getLessons()) {
            if (lesson.getType() == lessonType) {
                throw new IllegalStateException(course.getName() + " already has a " + lessonType + " instructor");
            }
        }
    }

    private void persist() {
        storage.saveDefault();
    }
}
