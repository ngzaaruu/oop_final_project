package Model.service;

import Model.academic.Course;
import Model.academic.Report;
import Model.communication.Comment;
import Model.communication.News;
import Model.communication.OfficialMessage;
import Model.communication.Request;
import Model.enums.CourseType;
import Model.enums.LessonType;
import Model.enums.NewsType;
import Model.exceptions.DuplicateRegistrationException;
import Model.exceptions.LowHIndexException;
import Model.exceptions.MaxCreditsExceededException;
import Model.exceptions.TooManyFailsException;
import Model.research.Researcher;
import Model.users.GraduateStudent;
import Model.users.Manager;
import Model.users.Student;
import Model.users.Teacher;
import Model.users.User;
import Model.academic.Lesson;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class ManagerService {

    private final DataStorage storage;
    private final Logger logger;

    public ManagerService() {
        this(DataStorage.getInstance(), Logger.getInstance());
    }

    public ManagerService(DataStorage storage, Logger logger) {
        this.storage = storage;
        this.logger = logger;
    }

    public Course createCourse(Manager manager, int id, String name, CourseType type,
                               int credits, String majorTarget, int yearOfStudy) {
        requireManager(manager);
        Course course = new Course(id, name, type, credits, majorTarget, yearOfStudy);
        storage.addCourse(course);
        manager.addCourseForRegistration(course);
        logger.log(manager, "Created course: " + course.getName());
        persist();
        return course;
    }

    public Lesson assignCourseToTeacher(Manager manager, Course course, Teacher teacher, LessonType lessonType) {
        requireManager(manager);
        if (course == null || teacher == null || lessonType == null) {
            throw new IllegalArgumentException("Course, teacher and lesson type cannot be null");
        }
        ensureLessonTypeAvailable(course, lessonType);

        manager.assignCourseToTeacher(course, teacher);
        Lesson lesson = new Lesson(generateLessonId(course, lessonType), lessonType, new Date(), teacher, course);
        logger.log(manager, "Assigned " + course.getName() + " " + lessonType + " to " + teacher.getFullName());
        persist();
        return lesson;
    }

    public void approveRegistration(Manager manager, Student student, Course course)
            throws MaxCreditsExceededException, TooManyFailsException, DuplicateRegistrationException {
        requireManager(manager);
        if (!manager.approveRegistration(student, course)) {
            throw new IllegalArgumentException("Student and course are required");
        }
        logger.log(manager, "Approved registration for " + student.getFullName());
        persist();
    }

    public News publishNews(Manager manager, User author, String title, String content, NewsType type) {
        requireManager(manager);
        if (author == null) {
            throw new IllegalArgumentException("Author cannot be null");
        }
        News news = new News(title, content, type, author);
        storage.addNews(news);
        manager.manageNews(news);
        logger.log(manager, "Published news: " + title + " as " + author.getFullName());
        persist();
        return news;
    }

    public Report createStudentReport(Manager manager, Student student) {
        requireManager(manager);
        if (student == null) {
            throw new IllegalArgumentException("Student cannot be null");
        }
        Report report = new ReportService().generateStudentReport(student);
        logger.log(manager, "Created academic report for " + student.getFullName());
        return report;
    }

    public Report createAcademicPerformanceReport(Manager manager) {
        requireManager(manager);
        Report report = manager.createAcademicPerformanceReport(getStudents());
        logger.log(manager, "Created academic performance report");
        return report;
    }

    public List<Student> getStudents() {
        List<Student> students = new ArrayList<>();
        for (User user : storage.getUsers()) {
            if (user instanceof Student student) {
                students.add(student);
            }
        }
        return students;
    }

    public List<Teacher> getTeachers() {
        List<Teacher> teachers = new ArrayList<>();
        for (User user : storage.getUsers()) {
            if (user instanceof Teacher teacher) {
                teachers.add(teacher);
            }
        }
        return teachers;
    }

    public List<Course> getCourses() {
        return storage.getCourses();
    }

    public List<News> getNews() {
        return storage.getNews();
    }

    public Comment addCommentToNews(Manager manager, News news, String text) {
        requireManager(manager);
        if (news == null) {
            throw new IllegalArgumentException("News cannot be null");
        }
        Comment comment = new Comment(text, manager, news);
        logger.log(manager, "Commented news: " + news.getTitle());
        persist();
        return comment;
    }

    public OfficialMessage createOfficialMessage(Manager manager, String title, String details) {
        requireManager(manager);
        OfficialMessage message = new OfficialMessage(title, details, manager);
        storage.addOfficialMessage(message);
        logger.log(manager, "Created official message: " + title);
        persist();
        return message;
    }

    public List<OfficialMessage> getOfficialMessages() {
        return storage.getOfficialMessages();
    }

    public List<GraduateStudent> getGraduateStudents() {
        List<GraduateStudent> graduateStudents = new ArrayList<>();
        for (User user : storage.getUsers()) {
            if (user instanceof GraduateStudent graduateStudent) {
                graduateStudents.add(graduateStudent);
            }
        }
        return graduateStudents;
    }

    public List<Researcher> getResearchers() {
        List<Researcher> researchers = new ArrayList<>();
        for (User user : storage.getUsers()) {
            if (user instanceof Researcher researcher) {
                researchers.add(researcher);
            }
        }
        return researchers;
    }

    public void assignSupervisor(Manager manager, GraduateStudent graduateStudent, Researcher supervisor)
            throws LowHIndexException {
        requireManager(manager);
        if (graduateStudent == null || supervisor == null) {
            throw new IllegalArgumentException("Graduate student and supervisor cannot be null");
        }
        graduateStudent.setSupervisor(supervisor);
        logger.log(manager, "Assigned supervisor to " + graduateStudent.getFullName());
        persist();
    }

    public List<Request> getRequests(Manager manager) {
        requireManager(manager);
        return manager.viewRequests();
    }

    public List<User> getUsers() {
        return storage.getUsers();
    }

    public void signRequest(Manager manager, Request request) {
        requireManager(manager);
        manager.signRequest(request);
        logger.log(manager, "Signed request: " + request.getDescription());
        persist();
    }

    public List<Student> getStudentsSortedByName() {
        List<Student> students = getStudents();
        students.sort(Comparator.comparing(Student::getFullName));
        return students;
    }

    private void requireManager(Manager manager) {
        if (manager == null) {
            throw new IllegalArgumentException("Manager is required");
        }
    }

    private int generateLessonId(Course course, LessonType lessonType) {
        return Math.abs((course.hashCode() + lessonType.hashCode() + course.getLessons().size()) % 1_000_000);
    }

    private void ensureLessonTypeAvailable(Course course, LessonType lessonType) {
        for (Lesson lesson : course.getLessons()) {
            if (lesson.getType() == lessonType) {
                throw new IllegalStateException(course.getName() + " already has a " + lessonType + " instructor");
            }
        }
    }

    private void persist() {
        storage.saveDefault();
    }
}
