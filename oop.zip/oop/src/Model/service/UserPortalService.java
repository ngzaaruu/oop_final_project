package Model.service;

import Model.communication.Journal;
import Model.communication.Message;
import Model.communication.News;
import Model.users.User;

import java.util.List;

public class UserPortalService {

    private final DataStorage storage;
    private final Logger logger;

    public UserPortalService() {
        this(DataStorage.getInstance(), Logger.getInstance());
    }

    public UserPortalService(DataStorage storage, Logger logger) {
        this.storage = storage;
        this.logger = logger;
    }

    public List<News> getNews() {
        return storage.getNews();
    }

    public List<Journal> getJournals() {
        return storage.getJournals();
    }

    public void subscribeToJournal(User user, Journal journal) {
        if (user == null || journal == null) {
            throw new IllegalArgumentException("User and journal cannot be null");
        }
        storage.addJournal(journal);
        journal.subscribe(user);
        logger.log(user, "Subscribed to journal: " + journal.getName());
        persist();
    }

    public List<User> getMessageReceivers(User currentUser) {
        List<User> users = new java.util.ArrayList<>();
        for (User user : storage.getUsers()) {
            if (!user.equals(currentUser)) {
                users.add(user);
            }
        }
        return users;
    }

    public void sendMessage(User sender, User receiver, String text) {
        if (sender == null || receiver == null) {
            throw new IllegalArgumentException("Sender and receiver cannot be null");
        }
        sender.sendMessage(receiver, text);
        logger.log(sender, "Sent message to " + receiver.getFullName());
        persist();
    }

    public List<Message> getInbox(User user) {
        if (user == null) {
            throw new IllegalArgumentException("User cannot be null");
        }
        return user.getInbox();
    }

    public List<Message> getSentMessages(User user) {
        if (user == null) {
            throw new IllegalArgumentException("User cannot be null");
        }
        return user.getSentMessages();
    }

    private void persist() {
        storage.saveDefault();
    }
}
