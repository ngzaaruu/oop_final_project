package app;

import Model.academic.Course;
import Model.academic.Mark;
import Model.communication.Request;
import Model.enums.CourseType;
import Model.enums.Language;
import Model.enums.LessonType;
import Model.enums.ManagerType;
import Model.research.ResearchPaper;
import Model.research.ResearchProject;
import Model.service.AdminService;
import Model.service.AuthService;
import Model.service.DataStorage;
import Model.service.ManagerService;
import Model.service.ResearchService;
import Model.service.StudentService;
import Model.service.TeacherService;
import Model.service.TechSupportService;
import Model.service.UserPortalService;
import Model.users.Admin;
import Model.users.GraduateStudent;
import Model.users.Manager;
import Model.users.ResearchEmployee;
import Model.users.Student;
import Model.users.Teacher;
import Model.users.TechSupportSpecialist;
import Model.users.User;
import controllers.AdminController;
import controllers.LoginController;
import controllers.ManagerController;
import controllers.ResearcherController;
import controllers.StudentController;
import controllers.TeacherController;
import controllers.TechSupportController;
import controllers.UserPortalController;
import core.Database;
import core.utils.ConsolePrinter;
import core.utils.LanguageManager;
import views.AdminView;
import views.LoginView;
import views.ManagerView;
import views.ResearcherView;
import views.StudentView;
import views.TeacherView;
import views.TechSupportView;
import views.UserPortalView;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Runtime.getRuntime().addShutdownHook(new Thread(Main::saveData));
        loadData();
        seedData();

        AuthService authService = new AuthService();
        LoginController loginController = new LoginController(authService, new LoginView(scanner));

        boolean running = true;
        while (running) {
            ConsolePrinter.printMenu("RESEARCH ORIENTED UNIVERSITY SYSTEM", new String[]{
                    LanguageManager.text("Login", "Kiru", "Вход"),
                    LanguageManager.text("Show demo accounts", "Demo accounttar", "Демо-аккаунты"),
                    LanguageManager.text("Change language", "Tildi ozgertu", "Изменить язык"),
                    LanguageManager.text("Exit", "Shygu", "Выход")
            });

            switch (readInt(scanner, promptChoose())) {
                case 1 -> {
                    User user = loginController.login();
                    if (user != null) {
                        openUserSession(user, scanner);
                        loginController.logout();
                    }
                }
                case 2 -> showDemoAccounts();
                case 3 -> changeLanguage(scanner);
                case 4 -> running = false;
                default -> ConsolePrinter.printError("Unknown option");
            }
        }

        ConsolePrinter.printSuccess("Goodbye.");
    }

    private static void openUserSession(User user, Scanner scanner) {
        boolean choosing = true;
        while (choosing) {
            ConsolePrinter.printMenu(LanguageManager.text("USER SESSION", "PAIDALANUSHY SESSIIASY", "СЕССИЯ ПОЛЬЗОВАТЕЛЯ"), new String[]{
                    LanguageManager.text("Common user portal", "Jalpy portal", "Общий портал"),
                    LanguageManager.text("Role menu", "Rol menu", "Меню роли"),
                    LanguageManager.text("Logout", "Shygu", "Выйти")
            });
            switch (readInt(scanner, promptChoose())) {
                case 1 -> new UserPortalController(new UserPortalService(), new UserPortalView(scanner)).openMenu(user);
                case 2 -> openRoleMenu(user, scanner);
                case 3 -> choosing = false;
                default -> ConsolePrinter.printError("Unknown option");
            }
        }
    }

    private static void loadData() {
        try {
            if (Database.loadDefault()) {
                ConsolePrinter.printSuccess("Data loaded from " + Database.DEFAULT_FILE);
            }
        } catch (IllegalStateException e) {
            ConsolePrinter.printError("Could not load saved data: " + e.getMessage());
        }
    }

    private static void saveData() {
        try {
            Database.saveDefault();
            ConsolePrinter.printSuccess("Data saved to " + Database.DEFAULT_FILE);
        } catch (IllegalStateException e) {
            ConsolePrinter.printError("Could not save data: " + e.getMessage());
        }
    }

    private static void openRoleMenu(User user, Scanner scanner) {
        if (user instanceof Admin admin) {
            new AdminController(new AdminService(), new AdminView(scanner)).openMenu(admin);
            return;
        }
        if (user instanceof Manager manager) {
            new ManagerController(new ManagerService(), new ManagerView(scanner)).openMenu(manager);
            return;
        }
        if (user instanceof TechSupportSpecialist specialist) {
            new TechSupportController(new TechSupportService(), new TechSupportView(scanner)).openMenu(specialist);
            return;
        }
        if (user instanceof GraduateStudent graduateStudent) {
            openGraduateStudentMenu(graduateStudent, scanner);
            return;
        }
        if (user instanceof Teacher teacher) {
            openTeacherMenu(teacher, scanner);
            return;
        }
        if (user instanceof ResearchEmployee researcher) {
            new ResearcherController(new ResearchService(), new ResearcherView(scanner)).openMenu(researcher);
            return;
        }
        if (user instanceof Student student) {
            openStudentMenu(student, scanner);
            return;
        }

        ConsolePrinter.printError("No console menu for this role");
    }

    private static void openStudentMenu(Student student, Scanner scanner) {
        boolean choosing = true;
        while (choosing) {
            ConsolePrinter.printMenu(LanguageManager.text("STUDENT MODE", "STUDENT REJIMI", "РЕЖИМ СТУДЕНТА"), new String[]{
                    LanguageManager.text("Student menu", "Student menu", "Меню студента"),
                    LanguageManager.text("Researcher menu", "Zertteushi menu", "Меню исследователя"),
                    LanguageManager.text("Back", "Artqa", "Назад")
            });
            switch (readInt(scanner, promptChoose())) {
                case 1 -> new StudentController(new StudentService(), new StudentView(scanner)).openMenu(student);
                case 2 -> new ResearcherController(new ResearchService(), new ResearcherView(scanner)).openMenu(student);
                case 3 -> choosing = false;
                default -> ConsolePrinter.printError("Unknown option");
            }
        }
    }

    private static void openGraduateStudentMenu(GraduateStudent graduateStudent, Scanner scanner) {
        boolean choosing = true;
        while (choosing) {
            ConsolePrinter.printMenu(LanguageManager.text("GRADUATE STUDENT MODE", "MAGISTRANT REJIMI", "РЕЖИМ МАГИСТРАНТА"), new String[]{
                    LanguageManager.text("Student menu", "Student menu", "Меню студента"),
                    LanguageManager.text("Researcher menu", "Zertteushi menu", "Меню исследователя"),
                    LanguageManager.text("Graduate profile", "Magistrant profili", "Профиль магистранта"),
                    LanguageManager.text("Back", "Artqa", "Назад")
            });
            switch (readInt(scanner, promptChoose())) {
                case 1 -> new StudentController(new StudentService(), new StudentView(scanner)).openMenu(graduateStudent);
                case 2 -> new ResearcherController(new ResearchService(), new ResearcherView(scanner)).openMenu(graduateStudent);
                case 3 -> showGraduateProfile(graduateStudent);
                case 4 -> choosing = false;
                default -> ConsolePrinter.printError("Unknown option");
            }
        }
    }

    private static void showGraduateProfile(GraduateStudent graduateStudent) {
        ConsolePrinter.printInfo("Name", graduateStudent.getFullName());
        ConsolePrinter.printInfo("Degree", graduateStudent.getDegreeType());
        ConsolePrinter.printInfo("Thesis topic", graduateStudent.getThesisTopic());
        ConsolePrinter.printInfo("Supervisor", graduateStudent.getSupervisor() == null
                ? "Not assigned"
                : String.valueOf(graduateStudent.getSupervisor()));
        ConsolePrinter.printInfo("Diploma papers", String.valueOf(graduateStudent.getPublishedDiplomaPapers().size()));
    }

    private static void openTeacherMenu(Teacher teacher, Scanner scanner) {
        boolean choosing = true;
        while (choosing) {
            ConsolePrinter.printMenu(LanguageManager.text("TEACHER MODE", "MUGALIM REJIMI", "РЕЖИМ ПРЕПОДАВАТЕЛЯ"), new String[]{
                    LanguageManager.text("Teacher menu", "Mugalim menu", "Меню преподавателя"),
                    LanguageManager.text("Researcher menu", "Zertteushi menu", "Меню исследователя"),
                    LanguageManager.text("Back", "Artqa", "Назад")
            });
            switch (readInt(scanner, promptChoose())) {
                case 1 -> new TeacherController(new TeacherService(), new TeacherView(scanner)).openMenu(teacher);
                case 2 -> new ResearcherController(new ResearchService(), new ResearcherView(scanner)).openMenu(teacher);
                case 3 -> choosing = false;
                default -> ConsolePrinter.printError("Unknown option");
            }
        }
    }

    private static void seedData() {
        DataStorage storage = DataStorage.getInstance();
        if (!storage.getUsers().isEmpty()) {
            if (storage.findUserByEmail("graduate@uni.kz") == null) {
                storage.addUser(new GraduateStudent(7, "Dias Graduate", "graduate@uni.kz", "graduate123",
                        "+77010000007", Language.EN, "GS7", "CS", 2,
                        "Adaptive LMS Analytics", "MASTER"));
            }
            if (storage.findUserByEmail("supervisor@uni.kz") == null) {
                ResearchEmployee supervisor = createSupervisor();
                storage.addUser(supervisor);
                supervisor.getResearchPapers().forEach(storage::addPaper);
            }
            return;
        }

        Admin admin = new Admin(1, "System Admin", "admin@uni.kz", "admin123",
                "+77010000001", Language.EN, "EMP1", "ADM1", "HIGH");
        Student student = new Student(2, "Aruzhan Student", "student@uni.kz", "student123",
                "+77010000002", Language.EN, "ST2", "CS", 1);
        Teacher teacher = new Teacher(3, "Dana Teacher", "teacher@uni.kz", "teacher123",
                "+77010000003", Language.EN, "EMP3", BigDecimal.valueOf(500000),
                "A201", "CS", "T3", "LECTOR");
        Manager manager = new Manager(4, "Miras Manager", "manager@uni.kz", "manager123",
                "+77010000004", Language.EN, "EMP4", "M4", ManagerType.DEAN);
        TechSupportSpecialist support = new TechSupportSpecialist(5, "IT Support", "support@uni.kz", "support123",
                "+77010000005", Language.EN, "EMP5", BigDecimal.valueOf(300000),
                "IT1", "IT", "TS5");
        ResearchEmployee researcher = new ResearchEmployee(6, "Aliya Researcher", "researcher@uni.kz", "research123",
                "+77010000006", Language.EN, "EMP6", BigDecimal.valueOf(650000),
                "R101", "Research Center");
        GraduateStudent graduateStudent = new GraduateStudent(7, "Dias Graduate", "graduate@uni.kz", "graduate123",
                "+77010000007", Language.EN, "GS7", "CS", 2,
                "Adaptive LMS Analytics", "MASTER");
        ResearchEmployee supervisor = createSupervisor();

        List.of(admin, student, teacher, manager, support, researcher, graduateStudent, supervisor).forEach(storage::addUser);

        Course oop = new Course(101, "Object Oriented Programming", CourseType.MAJOR, 5, "CS", 1);
        Course databases = new Course(102, "Databases", CourseType.MAJOR, 5, "CS", 2);
        storage.addCourse(oop);
        storage.addCourse(databases);

        manager.assignCourseToTeacher(oop, teacher);
        new Model.academic.Lesson(1, LessonType.LECTURE, new Date(), teacher, oop);
        try {
            student.registerCourse(oop);
            new Mark(27, 28, 35, student, oop);
        } catch (Exception e) {
            ConsolePrinter.printError(e.getMessage());
        }

        ResearchPaper paper = new ResearchPaper(
                "AI in Higher Education",
                List.of("Aliya Researcher"),
                "University Research Journal",
                12,
                8,
                new Date(),
                "10.1000/demo"
        );
        researcher.addResearchPaper(paper);
        storage.addPaper(paper);
        supervisor.getResearchPapers().forEach(storage::addPaper);

        ResearchService researchService = new ResearchService();
        researchService.addProject(new ResearchProject("RP-1", "Smart Campus Analytics", new Date()));

        new Request("Computer in lab does not work", student);
    }

    private static void showDemoAccounts() {
        ConsolePrinter.printTable(
                List.of("Role", "Email", "Password"),
                List.of(
                        List.of("Admin", "admin@uni.kz", "admin123"),
                        List.of("Student", "student@uni.kz", "student123"),
                        List.of("Teacher", "teacher@uni.kz", "teacher123"),
                        List.of("Manager", "manager@uni.kz", "manager123"),
                        List.of("Tech support", "support@uni.kz", "support123"),
                        List.of("Researcher", "researcher@uni.kz", "research123"),
                        List.of("Supervisor", "supervisor@uni.kz", "supervisor123"),
                        List.of("Graduate student", "graduate@uni.kz", "graduate123")
                )
        );
    }

    private static ResearchEmployee createSupervisor() {
        ResearchEmployee supervisor = new ResearchEmployee(8, "Professor Supervisor", "supervisor@uni.kz", "supervisor123",
                "+77010000008", Language.EN, "EMP8", BigDecimal.valueOf(700000),
                "R202", "Research Center");
        supervisor.addResearchPaper(new ResearchPaper("Learning Analytics A", List.of("Professor Supervisor"), "Journal A", 10, 5, new Date(), "10.1000/s1"));
        supervisor.addResearchPaper(new ResearchPaper("Learning Analytics B", List.of("Professor Supervisor"), "Journal B", 11, 4, new Date(), "10.1000/s2"));
        supervisor.addResearchPaper(new ResearchPaper("Learning Analytics C", List.of("Professor Supervisor"), "Journal C", 12, 3, new Date(), "10.1000/s3"));
        return supervisor;
    }

    private static void changeLanguage(Scanner scanner) {
        ConsolePrinter.printMenu("LANGUAGE", new String[]{"English", "Qazaqsha", "Русский"});
        switch (readInt(scanner, promptChoose())) {
            case 1 -> LanguageManager.setCurrentLanguage(Language.EN);
            case 2 -> LanguageManager.setCurrentLanguage(Language.KZ);
            case 3 -> LanguageManager.setCurrentLanguage(Language.RU);
            default -> ConsolePrinter.printError("Unknown language");
        }
    }

    private static String promptChoose() {
        return LanguageManager.text("Choose: ", "Tandau: ", "Выберите: ");
    }

    private static int readInt(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                ConsolePrinter.printError("Enter a valid number");
            }
        }
    }
}
